------Thank you for downloading the Poly Engine!------

Please, do not install the Poly Engine on C drive partition. The engine might not work properly.
Thanks again and enjoy!

------How to use example projects?--------

After engine installation, copy and paste example project into engine Data directory.
Done! Enjoy.

by Matej Vanco 27.10.2019
contact: https://matejvanco.com/contact