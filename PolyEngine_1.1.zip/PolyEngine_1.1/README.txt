------Thank you for downloading the Poly Engine!------

Please, do not install the Poly Engine on C drive partition. The engine might not work properly.
Thanks again and enjoy!

------How to use example projects?--------

After engine installation, copy and paste example project into engine Data directory.
Enjoy!

by Matej Vanco 18.10.2020
support: https://matejvanco.com/contact